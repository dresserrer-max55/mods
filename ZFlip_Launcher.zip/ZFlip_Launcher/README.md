# ZFlip Launcher

Launcher de mods para Geometry Dash (Android) con su propio formato de mods: **.zflip**.
Por defecto no usa ni depende de Geode; el soporte de mods `.geode` es opcional (ver abajo).

* El launcher carga las librerías del Geometry Dash instalado y después el motor ZFlip (`libzflip.so`).
* Los mods son librerías nativas empaquetadas en `.zflip` (ver `sdk/`).
* Cada mod declara las versiones de GD que soporta; si no coincide, no se carga y se avisa sin cerrar el juego.
* En el menú principal del juego aparece un botón «MODS» con la lista y el estado de cada mod.

El código que arranca el juego en Android (clases `org.cocos2dx.*`, `org.fmod.*`, `com.customRobTop.*`
y el parche `launcherfix`) proviene del launcher oficial de Geode, licencia Boost
(https://github.com/geode-sdk/android-launcher); ver LICENSE.txt. Los hooks usan ShadowHook (MIT).


## Soporte opcional de Geode (mods .geode, p. ej. Globed)

ZFlip puede cargar el loader de Geode **si lo instalas**; si no, funciona exactamente igual que antes.

1. Ejecuta el workflow `build-geode-mods.yml` (repo de mods): compila el loader de Geode y un mod
   (por defecto Globed) **desde el código fuente para GD 2.2091**. Descarga el artefacto `geode-2.2091-build`.
2. En la app: *Mods (.zflip / .geode)* → *＋ Añadir mod* y elige, uno a uno:
   `Geode.android64.so` (o `android32`), `resources.zip` y el/los `.geode`.
3. Abre el juego. Geode se carga antes que el motor ZFlip; los `.zflip` siguen funcionando.

* Los `.geode` van a `Android/media/com.zflip.launcher/game/geode/mods/`.
* Un `.geode` publicado para otra versión de GD no sirve tal cual: hay que recompilarlo contra los bindings de tu versión.
* Si Geode tumba el juego al arrancar, se desactiva solo en el siguiente arranque (interruptor en el gestor de mods).
* Geode necesita la clase `com.geode.launcher.utils.GeodeUtils` con ese nombre exacto (la llama por JNI); no la renombres.
