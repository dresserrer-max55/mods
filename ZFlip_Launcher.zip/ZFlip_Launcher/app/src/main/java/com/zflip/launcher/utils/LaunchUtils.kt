package com.zflip.launcher.utils

import android.content.Context
import android.os.Build
import java.io.File
import java.io.Serializable

object LaunchUtils {
    // CPU_ABI devuelve la arquitectura del proceso actual
    @Suppress("DEPRECATION")
    val applicationArchitecture: String = Build.CPU_ABI

    val is64bit = applicationArchitecture == "arm64-v8a"

    /** Carpeta base visible para el usuario (Android/media/com.zflip.launcher). */
    fun getBaseDirectory(context: Context, @Suppress("UNUSED_PARAMETER") ignoreProfile: Boolean = false): File {
        @Suppress("DEPRECATION")
        val dir = context.externalMediaDirs.firstOrNull()
            ?: context.getExternalFilesDir(null)
            ?: context.filesDir

        dir.mkdirs()
        // evita que los recursos aparezcan en la galería
        File(dir, ".nomedia").createNewFile()
        return dir
    }

    fun getSaveDirectory(context: Context): File = File(getBaseDirectory(context), "save")

    // ---- Geode (loader opcional para mods .geode) ----

    /** "android64" o "android32": el sufijo que usan los binarios de Geode. */
    val platformName: String = if (is64bit) "android64" else "android32"

    /** Geode.android64.so / Geode.android32.so */
    val geodeFilename: String = "Geode.$platformName.so"

    /**
     * Busca el loader de Geode compilado para esta ABI (el mismo orden que el launcher oficial):
     * filesDir/launcher/, <base>/launcher/ y <base>/. Devuelve null si no está instalado.
     */
    fun getInstalledGeodePath(context: Context): File? {
        val candidates = listOf(
            File(context.filesDir, "launcher/$geodeFilename"),
            File(getBaseDirectory(context), "launcher/$geodeFilename"),
            File(getBaseDirectory(context), geodeFilename),
        )
        return candidates.firstOrNull { it.isFile }
    }

    /** Aquí van los .geode (Geode los lee de <base>/game/geode/mods). */
    fun getGeodeModsDirectory(context: Context): File =
        File(getBaseDirectory(context), "game/geode/mods").apply { mkdirs() }

    /** Recursos del loader de Geode (archivos sueltos de resources.zip). */
    fun getGeodeResourcesDirectory(context: Context): File =
        File(getBaseDirectory(context), "game/geode/resources/geode.loader").apply { mkdirs() }

    /** Aquí van los archivos .zflip. */
    fun getModsDirectory(context: Context): File =
        File(getBaseDirectory(context), "mods").apply { mkdirs() }

    /** Carpeta privada de datos de cada mod. */
    fun getModDataDirectory(context: Context, modId: String): File =
        File(getBaseDirectory(context), "moddata/$modId").apply { mkdirs() }

    enum class LauncherError : Serializable {
        LINKER_NEEDS_64BIT,
        LINKER_NEEDS_32BIT,
        LINKER_FAILED_STL,
        LINKER_FAILED,
        GENERIC
    }

    const val KEY_RETURN_ERROR = "return_error"
    const val KEY_RETURN_MESSAGE = "return_message"
    const val KEY_RETURN_EXTENDED_MESSAGE = "return_extended_message"
}
