package com.zflip.launcher.utils

import java.io.InputStream
import java.io.OutputStream

object DownloadUtils {
    /** Copia inputStream en outputStream y cierra ambos. */
    fun copyFile(inputStream: InputStream, outputStream: OutputStream) {
        inputStream.use { input -> outputStream.use { output -> input.copyTo(output) } }
    }
}
