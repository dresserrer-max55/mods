package com.zflip.launcher

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.util.Log
import com.zflip.launcher.utils.DownloadUtils
import com.zflip.launcher.utils.LaunchUtils
import java.io.File

/**
 * Soporte OPCIONAL para mods .geode. ZFlip no incluye Geode: carga el loader (Geode.android64.so /
 * Geode.android32.so, compilado para la versión de GD instalada) solo si el usuario lo instaló, y
 * Geode se encarga de sus propios mods (<base>/game/geode/mods/*.geode).
 *
 * Los mods .geode viejos NO funcionan tal cual con otra versión de GD: hay que recompilarlos contra
 * los bindings de esa versión (ver build-geode-mods.yml).
 */
object GeodeManager {
    private const val TAG = "ZFlipGeode"
    private const val PREFS = "zflip"
    private const val KEY_ENABLED = "geode_enabled"

    const val MOD_EXTENSION = ".geode"

    enum class State { NOT_INSTALLED, DISABLED, LOADED, CRASHED, ERROR }

    @Volatile
    var lastState: State = State.NOT_INSTALLED
        private set

    @Volatile
    var lastDetail: String = ""
        private set

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isEnabled(c: Context) = prefs(c).getBoolean(KEY_ENABLED, true)
    fun setEnabled(c: Context, v: Boolean) = prefs(c).edit().putBoolean(KEY_ENABLED, v).apply()

    fun installedLoader(c: Context): File? = LaunchUtils.getInstalledGeodePath(c)

    fun listMods(c: Context): List<File> =
        LaunchUtils.getGeodeModsDirectory(c)
            .listFiles { f -> f.isFile && f.name.endsWith(MOD_EXTENSION, true) }
            ?.sortedBy { it.name.lowercase() } ?: emptyList()

    /** Copia el loader a filesDir/launcher/ con el nombre que espera esta ABI. */
    fun installLoader(c: Context, uri: Uri) {
        val dest = File(c.filesDir, "launcher/${LaunchUtils.geodeFilename}")
        dest.parentFile?.mkdirs()
        dest.delete()
        c.contentResolver.openInputStream(uri).use { input ->
            if (input == null) throw IllegalStateException("no se pudo abrir el archivo")
            dest.outputStream().use { input.copyTo(it) }
        }
    }

    /** Extrae resources.zip (archivos sueltos) en game/geode/resources/geode.loader. Devuelve cuántos. */
    fun installResources(c: Context, uri: Uri): Int {
        val dir = LaunchUtils.getGeodeResourcesDirectory(c)
        var n = 0
        c.contentResolver.openInputStream(uri).use { raw ->
            if (raw == null) throw IllegalStateException("no se pudo abrir el archivo")
            java.util.zip.ZipInputStream(raw).use { zip ->
                while (true) {
                    val e = zip.nextEntry ?: break
                    if (e.isDirectory) continue
                    // solo el nombre del archivo: evita rutas con ../ (zip-slip)
                    val name = e.name.substringAfterLast('/')
                    if (name.isEmpty()) continue
                    File(dir, name).outputStream().use { zip.copyTo(it) }
                    n++
                }
            }
        }
        return n
    }

    fun installMod(c: Context, uri: Uri, name: String): File {
        val dest = File(LaunchUtils.getGeodeModsDirectory(c), name.replace('/', '_'))
        c.contentResolver.openInputStream(uri).use { input ->
            if (input == null) throw IllegalStateException("no se pudo abrir el archivo")
            dest.outputStream().use { input.copyTo(it) }
        }
        return dest
    }

    /**
     * Carga Geode si está instalado y activado. Nunca lanza.
     * Debe llamarse con libcocos2dcpp.so ya cargada, GeodeUtils.setContext hecho y game_version.txt escrito.
     * Un fallo nativo que mate el proceso deja un marcador: en el siguiente arranque Geode se
     * desactiva solo (igual que hace ZFlip con sus mods).
     */
    @SuppressLint("UnsafeDynamicallyLoadedCode")
    fun load(c: Context) {
        val guard = File(c.filesDir, "zflip_geode_loading.txt")
        if (guard.exists()) {
            guard.delete()
            setEnabled(c, false)
            lastState = State.CRASHED
            lastDetail = "cerró el juego al cargarse; se desactivó automáticamente"
            ZLog.w(TAG, "Geode tumbó el proceso en el arranque anterior: desactivado")
            return
        }

        val loader = installedLoader(c)
        when {
            loader == null -> {
                lastState = State.NOT_INSTALLED
                lastDetail = "no hay ${LaunchUtils.geodeFilename}"
                return
            }
            !isEnabled(c) -> {
                lastState = State.DISABLED
                lastDetail = "desactivado"
                return
            }
        }

        try {
            // Android no deja cargar código desde Android/media: se copia a almacenamiento interno
            val toLoad = if (loader!!.startsWith(c.filesDir)) loader else {
                val dir = File(c.filesDir, "copied").apply { deleteRecursively(); mkdirs() }
                File(dir, "Geode.so").also { copy ->
                    loader.inputStream().use { i -> copy.outputStream().use { o -> DownloadUtils.copyFile(i, o) } }
                    copy.setWritable(false) // Android 14+: el código dinámico debe ser de solo lectura
                }
            }
            guard.writeText("geode")
            ZLog.i(TAG, "cargando Geode desde ${loader.path}")
            System.load(toLoad.path)
            guard.delete()
            lastState = State.LOADED
            lastDetail = "cargado"
            ZLog.i(TAG, "Geode cargado")
        } catch (t: Throwable) {
            guard.delete()
            lastState = State.ERROR
            lastDetail = t.message ?: t.javaClass.simpleName
            ZLog.e(TAG, "no se pudo cargar Geode: ${Log.getStackTraceString(t)}")
        }
    }
}
