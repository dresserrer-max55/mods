package com.zflip.launcher.utils

import com.geode.launcher.utils.GeodeUtils

/**
 * Entradas "extendidas": solo se invocan cuando el loader de Geode las registró
 * (GeodeUtils.onCapabilityAdded activa los flags de Cocos2dxGLSurfaceView). Sin Geode nunca se llaman.
 * Antes eran stubs vacíos; ahora reenvían a GeodeUtils, cuyas funciones nativas registra Geode.
 */
object NativeInput {
    fun nativeKeyUp(keyCode: Int, modifiers: Int) = GeodeUtils.nativeKeyUp(keyCode, modifiers)
    fun nativeKeyDown(keyCode: Int, modifiers: Int, isRepeating: Boolean) =
        GeodeUtils.nativeKeyDown(keyCode, modifiers, isRepeating)
    fun nativeActionScroll(scrollX: Float, scrollY: Float) = GeodeUtils.nativeActionScroll(scrollX, scrollY)
    fun resizeSurface(width: Int, height: Int) = GeodeUtils.resizeSurface(width, height)
    fun setNextInputTimestamp(timestamp: Long) = GeodeUtils.setNextInputTimestamp(timestamp)

    const val TOUCH_TYPE_BEGIN = GeodeUtils.TOUCH_TYPE_BEGIN
    const val TOUCH_TYPE_MOVE = GeodeUtils.TOUCH_TYPE_MOVE
    const val TOUCH_TYPE_END = GeodeUtils.TOUCH_TYPE_END
    const val TOUCH_TYPE_CANCEL = GeodeUtils.TOUCH_TYPE_CANCEL

    fun internalKeyEvent(timestamp: Long, deviceId: Int, eventSource: Int, keyCode: Int, modifiers: Int, isDown: Boolean, repeatCount: Int) =
        GeodeUtils.internalKeyEvent(timestamp, deviceId, eventSource, keyCode, modifiers, isDown, repeatCount)
    fun internalTouchEvent(timestamp: Long, deviceId: Int, eventSource: Int, eventType: Int, ids: IntArray, xs: FloatArray, ys: FloatArray) =
        GeodeUtils.internalTouchEvent(timestamp, deviceId, eventSource, eventType, ids, xs, ys)
    fun internalScrollEvent(timestamp: Long, deviceId: Int, eventSource: Int, scrollX: Float, scrollY: Float, mouseX: Float, mouseY: Float) =
        GeodeUtils.internalScrollEvent(timestamp, deviceId, eventSource, scrollX, scrollY, mouseX, mouseY)
    fun internalJoystickEvent(timestamp: Long, deviceId: Int, eventSource: Int, leftX: FloatArray, leftY: FloatArray, rightX: FloatArray, rightY: FloatArray, hatX: FloatArray, hatY: FloatArray, leftTrigger: FloatArray, rightTrigger: FloatArray) =
        GeodeUtils.internalJoystickEvent(timestamp, deviceId, eventSource, leftX, leftY, rightX, rightY, hatX, hatY, leftTrigger, rightTrigger)

    fun inputDeviceAdded(deviceId: Int) = GeodeUtils.inputDeviceAdded(deviceId)
    fun inputDeviceChanged(deviceId: Int) = GeodeUtils.inputDeviceChanged(deviceId)
    fun inputDeviceRemoved(deviceId: Int) = GeodeUtils.inputDeviceRemoved(deviceId)
}
