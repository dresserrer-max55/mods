package com.zflip.launcher

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.widget.Button
import android.widget.TextView

/** Pequeñas utilidades para construir las pantallas del launcher sin XML. */
class Ui(private val ctx: Context) {
    companion object {
        val BG = Color.rgb(13, 15, 24)
        val PANEL = Color.rgb(24, 28, 43)
        val ROW = Color.rgb(31, 36, 54)
        val ACCENT = Color.rgb(102, 92, 255)
        val SECONDARY = Color.rgb(47, 53, 75)
        val DANGER = Color.rgb(72, 40, 55)
        val MUTED = Color.rgb(158, 166, 190)
        val GOOD = Color.rgb(90, 200, 120)
        val BAD = Color.rgb(235, 90, 100)
    }

    fun dp(v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    fun text(value: String, size: Int, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(ctx).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    fun button(label: String, color: Int = ACCENT, action: () -> Unit) = Button(ctx).apply {
        text = label
        textSize = 12f
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = rounded(color, 10)
        setPadding(dp(14), 0, dp(14), 0)
        setOnClickListener { action() }
    }

    fun pad(v: View, d: Int) {
        val p = dp(d)
        v.setPadding(p, p, p, p)
    }
}
