package com.zflip.launcher

import androidx.annotation.Keep

/** Puente a libzflip.so (hooks y carga de mods nativos). */
@Keep
object ZflipNative {
    fun loadLibrary() {
        System.loadLibrary("zflip")
    }

    /** Inicializa el motor de hooks. Devuelve 1 si los hooks del menú principal quedaron instalados. */
    external fun nativeInit(gameVersion: String, abi: String, logPath: String): Int

    /** Carga un mod. Devuelve null si fue bien, o el mensaje de error. */
    external fun nativeLoadMod(libPath: String, modId: String, dataDir: String): String?
}
