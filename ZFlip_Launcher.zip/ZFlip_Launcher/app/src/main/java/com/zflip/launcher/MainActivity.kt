package com.zflip.launcher

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.zflip.launcher.utils.GamePackageUtils
import com.zflip.launcher.utils.LaunchUtils

/** Pantalla principal del launcher. */
class MainActivity : AppCompatActivity() {
    private lateinit var ui: Ui
    private lateinit var infoBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ZLog.init(this)
        ZLog.captureCrashContext(this)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_USER_LANDSCAPE
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        ui = Ui(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Ui.BG)
            ui.pad(this, 16)
        }

        // --- columna izquierda: marca + acciones ---
        val left = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        left.addView(ui.text("ZFlip", 34, bold = true))
        left.addView(ui.text("Launcher de mods para Geometry Dash", 13, Ui.MUTED))
        left.addView(View(this), LinearLayout.LayoutParams(1, ui.dp(18)))
        left.addView(ui.button("▶  Jugar") { launchGame() }, LinearLayout.LayoutParams(-1, ui.dp(52)))
        left.addView(View(this), LinearLayout.LayoutParams(1, ui.dp(10)))
        left.addView(
            ui.button("Mods (.zflip / .geode)", Ui.SECONDARY) {
                startActivity(Intent(this, ModManagerActivity::class.java))
            },
            LinearLayout.LayoutParams(-1, ui.dp(44))
        )

        left.addView(View(this), LinearLayout.LayoutParams(1, ui.dp(10)))
        left.addView(
            ui.button("Registros (logs)", Ui.SECONDARY) {
                startActivity(Intent(this, LogsActivity::class.java))
            },
            LinearLayout.LayoutParams(-1, ui.dp(44))
        )
        left.addView(View(this), LinearLayout.LayoutParams(1, ui.dp(10)))
        left.addView(android.widget.Switch(this).apply {
            text = "Botón MODS flotante siempre"
            setTextColor(Ui.MUTED)
            textSize = 12f
            isChecked = ZflipLoader.alwaysFloating(this@MainActivity)
            setOnCheckedChangeListener { _, v -> ZflipLoader.setAlwaysFloating(this@MainActivity, v) }
        })

        // --- columna derecha: estado ---
        infoBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = ui.rounded(Ui.PANEL, 16)
            ui.pad(this, 16)
        }
        val scroll = ScrollView(this).apply { addView(infoBox) }

        root.addView(left, LinearLayout.LayoutParams(0, -1, 1f))
        root.addView(View(this), LinearLayout.LayoutParams(ui.dp(16), 1))
        root.addView(scroll, LinearLayout.LayoutParams(0, -1, 1.2f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refreshInfo()
    }

    private fun refreshInfo() {
        infoBox.removeAllViews()

        // error devuelto por GameActivity
        val message = intent.getStringExtra(LaunchUtils.KEY_RETURN_MESSAGE)
        if (message != null) {
            infoBox.addView(ui.text("El juego no pudo abrirse", 15, Ui.BAD, true))
            infoBox.addView(ui.text(message, 11, Ui.MUTED))
            infoBox.addView(View(this), LinearLayout.LayoutParams(1, ui.dp(10)))
        }

        val pm = packageManager
        val version = GamePackageUtils.getUnifiedVersionNameOrNull(pm)
        if (version == null) {
            infoBox.addView(ui.text("Geometry Dash no está instalado", 15, Ui.BAD, true))
            infoBox.addView(ui.text("Instálalo desde la tienda y vuelve aquí.", 12, Ui.MUTED))
        } else {
            infoBox.addView(ui.text("Geometry Dash $version detectado", 15, Ui.GOOD, true))
            infoBox.addView(ui.text("Arquitectura: ${LaunchUtils.applicationArchitecture}", 12, Ui.MUTED))
        }

        infoBox.addView(View(this), LinearLayout.LayoutParams(1, ui.dp(12)))
        val mods = ZflipLoader.listMods(this)
        val ok = mods.count { it.compatible }
        infoBox.addView(ui.text("Mods: ${mods.size} instalados · $ok compatibles", 14, bold = true))
        mods.forEach { m ->
            val enabled = ZflipLoader.isEnabled(this, m.id)
            val tag = when {
                !m.compatible -> "✖ no se puede ejecutar: ${m.reason}"
                enabled -> "✔ activo"
                else -> "• desactivado"
            }
            infoBox.addView(
                ui.text("• ${m.name} ${m.version} — $tag", 12, if (m.compatible) Ui.MUTED else Ui.BAD)
            )
        }
        if (mods.isEmpty()) {
            infoBox.addView(ui.text("Aún no hay mods. Usa «Mods (.zflip)» para añadir.", 12, Ui.MUTED))
        }

        // Geode (opcional)
        infoBox.addView(View(this), LinearLayout.LayoutParams(1, ui.dp(12)))
        val geodeLoader = GeodeManager.installedLoader(this)
        val geodeMods = GeodeManager.listMods(this).size
        infoBox.addView(
            ui.text(
                when {
                    geodeLoader == null -> "Geode: no instalado (opcional, para mods .geode)"
                    !GeodeManager.isEnabled(this) -> "Geode: desactivado · $geodeMods mods .geode"
                    else -> "Geode: ${geodeLoader.name} · $geodeMods mods .geode"
                },
                12, if (geodeLoader != null && GeodeManager.isEnabled(this)) Ui.GOOD else Ui.MUTED
            )
        )

        infoBox.addView(View(this), LinearLayout.LayoutParams(1, ui.dp(12)))
        infoBox.addView(
            ui.text(
                "Dentro del juego aparece un botón «MODS» en el menú principal, junto a los botones de logros y opciones.",
                11, Ui.MUTED
            )
        )
    }

    private fun launchGame() {
        startActivity(
            Intent(this, GameActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
            }
        )
    }
}
