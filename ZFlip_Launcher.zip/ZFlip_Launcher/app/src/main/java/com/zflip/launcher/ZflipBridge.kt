package com.zflip.launcher

import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.annotation.Keep

/** Callbacks que el código nativo llama desde el hilo del juego. */
@Keep
object ZflipBridge {
    interface MenuListener {
        /** true = el botón nativo del menú no se pudo crear: mostrar el botón de respaldo. */
        fun onMenuVisible(visible: Boolean)

        /** El usuario pulsó el botón «MODS» dentro del juego. */
        fun onShowMods()
    }

    @Volatile
    var listener: MenuListener? = null

    @Volatile
    var appContext: android.content.Context? = null

    private val main = Handler(Looper.getMainLooper())

    @JvmStatic
    fun onMenuVisible(visible: Boolean) {
        listener?.onMenuVisible(visible)
    }

    @JvmStatic
    fun showMods() {
        listener?.onShowMods()
    }

    @JvmStatic
    fun toast(message: String) {
        val ctx = appContext ?: return
        main.post { Toast.makeText(ctx, message, Toast.LENGTH_SHORT).show() }
    }
}
