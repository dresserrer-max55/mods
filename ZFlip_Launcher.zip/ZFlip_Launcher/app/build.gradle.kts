plugins {
    id("com.android.application")
}

android {
    namespace = "com.zflip.launcher"
    compileSdk = 37
    ndkVersion = "30.0.16248370"

    defaultConfig {
        applicationId = "com.zflip.launcher"
        minSdk = 23
        targetSdk = 37
        versionCode = 1
        versionName = "1.0.0"

        // lo lee GeodeUtils (copiado del launcher oficial de Geode)
        buildConfigField("boolean", "GOOGLE_PLAY_BUILD", "false")

        externalNativeBuild {
            cmake {
                arguments("-DANDROID_STL=c++_shared")
            }
        }

        ndk.abiFilters += listOf("arm64-v8a", "armeabi-v7a")
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    buildFeatures {
        buildConfig = true
        prefab = true
    }

    externalNativeBuild {
        cmake {
            version = "3.21.0+"
            path = file("src/main/cpp/CMakeLists.txt")
        }
    }

    packaging {
        jniLibs {
            // GD y los mods usan libc++_shared; solo una copia
            pickFirsts += "**/libc++_shared.so"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.19.1")
    implementation("androidx.activity:activity-ktx:1.13.0")
    implementation("androidx.appcompat:appcompat:1.8.0")
    implementation("androidx.browser:browser:1.10.0")
    implementation("androidx.documentfile:documentfile:1.1.0")
    implementation("com.bytedance.android:shadowhook:2.0.1")
}
