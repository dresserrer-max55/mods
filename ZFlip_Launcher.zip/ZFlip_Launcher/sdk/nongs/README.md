# NONGs (mod .zflip)

Cambia la música de un nivel por un audio tuyo.

* **Disco morado «O NONG»**: aparece en la **página del nivel** (la de comentarios, ranking, etc.), pegado a la
  barra de la música: a su derecha, o a su izquierda si no cabe. Ya **no** hay disco en el menú de pausa.
* Al pulsarlo se abre la ventana: «Original» + tus NONGs. Tocar un nombre lo activa (verde), «X» lo borra (pide confirmación),
  «+ Agregar» abre el selector de archivos de Android (necesita el launcher con el parche de `BaseRobTopActivity.kt`).
* El cambio se aplica al darle a jugar el nivel.

Archivos: `Android/media/com.zflip.launcher/moddata/nongs/nongs/<clave>/` (`c<ID>` = canción personalizada,
`o<N>` = pista oficial). Si el botón «+» no funciona puedes copiar ahí los audios a mano.

Ajustes: `.../moddata/nongs/config.txt` (reinicia el juego tras editarlo):

* `dx`, `dy`: mueven el disco en puntos respecto a la posición calculada junto a la música (dx + = derecha, dy + = arriba).
* `info_x`, `info_y`: posición de reserva (0 a 1) que se usa solo si no se encuentra la barra de la música.

Notas técnicas:

* No usa `ui_menu_priority` (falla con SIGSEGV en GD 2.2091 y abortaba la creación de la ventana).
* La barra de la música se localiza como el hijo `CustomSongWidget` de `LevelInfoLayer` (por la vtable o por el nombre
  RTTI) y se mide con los tamaños de sus hijos. En «Registros» (nivel DEBUG) se vuelca el árbol de la página del nivel y se
  anota `barra de la musica ... x=[..], y=..` para ajustar `dx`/`dy`.
* Mientras la ventana está abierta se ocultan los demás nodos de la página, así los toques no llegan a los botones de atrás.

Funciones del juego que engancha: `LevelTools::getAudioFileName`, `MusicDownloadManager::pathForSong`,
`MusicDownloadManager::isSongDownloaded` (imprescindibles: las dos primeras) y, opcionales,
`LevelInfoLayer::init`, `MusicDownloadManager::getSongInfoObject`, `LevelTools::getAudioTitle`,
`JniToCpp.filesPicked`. En «Registros» aparece cuál se pudo enganchar.
