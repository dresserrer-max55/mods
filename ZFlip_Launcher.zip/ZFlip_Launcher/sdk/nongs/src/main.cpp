// Mod «NONGs» para ZFlip (Geometry Dash 2.2091).
//
// Cambia la música de un nivel por un archivo de audio tuyo (un «NONG»).
//
//  - Un disco (círculo) aparece en la PÁGINA DEL NIVEL (la de comentarios, ranking, etc.), pegado a
//    la barra de la música. Ya no hay disco en el menú de pausa.
//  - Al pulsarlo se abre una ventana con las músicas de esa canción: «Original» y los NONGs
//    que hayas agregado. Tocar una la activa; la «X» borra un NONG; «+ Agregar» abre el
//    selector de archivos de Android.
//  - La música se cambia enganchando las funciones que le dicen al juego qué archivo
//    reproducir (LevelTools::getAudioFileName y MusicDownloadManager::pathForSong).
//
// Los archivos viven en <data_dir>/nongs/<clave>/ (clave = c<ID> canción personalizada,
// o<N> pista oficial). También puedes copiar ahí tus audios a mano.
// Ajustes en <data_dir>/config.txt (posición del disco). Elección guardada en selected.txt.
//
// Nota técnica: este mod NO usa ui_menu_priority. En GD 2.2091 CCMenu::setHandlerPriority provoca un
// SIGSEGV (dirección 0x40) y, al estar dentro de nuestra protección, abortaba la creación de la ventana.
#include <dirent.h>
#include <jni.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <csetjmp>
#include <csignal>
#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <map>
#include <mutex>
#include <string>
#include <vector>

#include "zflip.h"

static const ZflipApi* A = nullptr;

// ------------------------------------------------------------------ registro
static void logf(int level, const char* fmt, ...) __attribute__((format(printf, 2, 3)));
static void logf(int level, const char* fmt, ...) {
    char buf[600];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    if (A && A->log) A->log(level, buf);
}

// ------------------------------------------------------------------ protección contra cierres
// Igual que la del motor de ZFlip: si algo de nuestra interfaz falla con SIGSEGV/SIGBUS se registra
// y se sigue, en vez de cerrar el juego. Se encadena con el manejador que ya instaló el motor.
static sigjmp_buf g_jb;
static volatile sig_atomic_t g_guardOn = 0;
static struct sigaction g_old[32];

static void sig_handler(int sig, siginfo_t* info, void* ctx) {
    if (g_guardOn && (sig == SIGSEGV || sig == SIGBUS)) {
        g_guardOn = 0;
        siglongjmp(g_jb, 1);
    }
    if (sig < 32) {
        struct sigaction* o = &g_old[sig];
        if (o->sa_flags & SA_SIGINFO) {
            if (o->sa_sigaction) { o->sa_sigaction(sig, info, ctx); return; }
        } else if (o->sa_handler != SIG_DFL && o->sa_handler != SIG_IGN && o->sa_handler) {
            o->sa_handler(sig);
            return;
        }
    }
    signal(sig, SIG_DFL);
    raise(sig);
}

static void installGuard() {
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_sigaction = sig_handler;
    sa.sa_flags = SA_SIGINFO | SA_NODEFER;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGSEGV, &sa, &g_old[SIGSEGV]);
    sigaction(SIGBUS, &sa, &g_old[SIGBUS]);
}

template <typename F>
static bool guarded(const char* what, F f) {
    sigjmp_buf saved;
    memcpy(&saved, &g_jb, sizeof(saved));
    sig_atomic_t was = g_guardOn;
    volatile bool ok = true;
    if (sigsetjmp(g_jb, 1)) {
        logf(ZFLIP_LOG_ERROR, "nongs: FALLO EVITADO en %s", what);
        ok = false;
    } else {
        g_guardOn = 1;
        f();
    }
    g_guardOn = was;
    memcpy(&g_jb, &saved, sizeof(saved));
    return ok;
}

// ------------------------------------------------------------------ archivos
static std::string g_dataDir, g_root;

static bool existsPath(const std::string& p) { return access(p.c_str(), F_OK) == 0; }

static void mkdirs(const std::string& path) {
    std::string cur;
    for (size_t i = 0; i <= path.size(); i++) {
        if (i == path.size() || path[i] == '/') {
            if (!cur.empty()) mkdir(cur.c_str(), 0775);
        }
        if (i < path.size()) cur += path[i];
    }
}

static std::string lowerStr(std::string s) {
    for (auto& c : s) c = static_cast<char>(tolower(static_cast<unsigned char>(c)));
    return s;
}

static bool isAudioName(const std::string& name) {
    static const char* exts[] = {".mp3", ".ogg", ".wav", ".flac", ".m4a", ".aac", ".opus"};
    std::string l = lowerStr(name);
    for (const char* e : exts) {
        size_t n = strlen(e);
        if (l.size() > n && l.compare(l.size() - n, n, e) == 0) return true;
    }
    return false;
}

static std::string baseName(const std::string& p) {
    size_t s = p.rfind('/');
    return s == std::string::npos ? p : p.substr(s + 1);
}

static bool copyFile(const std::string& src, const std::string& dst) {
    FILE* in = fopen(src.c_str(), "rb");
    if (!in) return false;
    FILE* out = fopen(dst.c_str(), "wb");
    if (!out) { fclose(in); return false; }
    char buf[1 << 16];
    size_t n;
    bool ok = true;
    while ((n = fread(buf, 1, sizeof(buf), in)) > 0) {
        if (fwrite(buf, 1, n, out) != n) { ok = false; break; }
    }
    fclose(in);
    if (fclose(out) != 0) ok = false;
    if (!ok) unlink(dst.c_str());
    return ok;
}

static std::string keyDir(const std::string& key) { return g_root + "/" + key; }

// Archivos de audio de una canción, ordenados por nombre.
static std::vector<std::string> listFiles(const std::string& key) {
    std::vector<std::string> out;
    if (key.empty()) return out;
    DIR* d = opendir(keyDir(key).c_str());
    if (!d) return out;
    while (dirent* e = readdir(d)) {
        std::string n = e->d_name;
        if (n == "." || n == "..") continue;
        if (isAudioName(n)) out.push_back(n);
    }
    closedir(d);
    std::sort(out.begin(), out.end(), [](const std::string& a, const std::string& b) {
        return lowerStr(a) < lowerStr(b);
    });
    return out;
}

// ------------------------------------------------------------------ elección guardada
static std::mutex g_selMutex;
static std::map<std::string, std::string> g_sel;   // clave -> archivo activo

static void saveSelected() {
    std::lock_guard<std::mutex> lk(g_selMutex);
    FILE* f = fopen((g_dataDir + "/selected.txt").c_str(), "w");
    if (!f) return;
    for (auto& kv : g_sel) fprintf(f, "%s\t%s\n", kv.first.c_str(), kv.second.c_str());
    fclose(f);
}

static void loadSelected() {
    std::lock_guard<std::mutex> lk(g_selMutex);
    g_sel.clear();
    FILE* f = fopen((g_dataDir + "/selected.txt").c_str(), "r");
    if (!f) return;
    char line[1024];
    while (fgets(line, sizeof(line), f)) {
        std::string s = line;
        while (!s.empty() && (s.back() == '\n' || s.back() == '\r')) s.pop_back();
        size_t t = s.find('\t');
        if (t == std::string::npos || t == 0 || t + 1 >= s.size()) continue;
        g_sel[s.substr(0, t)] = s.substr(t + 1);
    }
    fclose(f);
}

static void setSelected(const std::string& key, const std::string& file) {
    {
        std::lock_guard<std::mutex> lk(g_selMutex);
        if (file.empty()) g_sel.erase(key);
        else g_sel[key] = file;
    }
    saveSelected();
}

static std::string getSelected(const std::string& key) {
    std::lock_guard<std::mutex> lk(g_selMutex);
    auto it = g_sel.find(key);
    return it == g_sel.end() ? std::string() : it->second;
}

// Ruta absoluta del NONG activo de esa canción (false = usar el original).
static bool pathFor(const std::string& key, std::string& out) {
    std::string f = getSelected(key);
    if (f.empty()) return false;
    std::string p = keyDir(key) + "/" + f;
    if (access(p.c_str(), R_OK) != 0) return false;
    out = p;
    return true;
}

// ------------------------------------------------------------------ ajustes
struct Config {
    // Posición de reserva (fracción de la pantalla) si no se encuentra la barra de la música.
    float infoX = 0.88f, infoY = 0.17f;
    // Desplazamiento en puntos respecto a la posición calculada junto a la barra de la música.
    float dx = 0.f, dy = 0.f;
} g_cfg;

static void loadConfig() {
    std::string path = g_dataDir + "/config.txt";
    FILE* f = fopen(path.c_str(), "r");
    if (f) {
        char line[256];
        while (fgets(line, sizeof(line), f)) {
            char* eq = strchr(line, '=');
            if (!eq) continue;
            *eq = 0;
            float v = static_cast<float>(atof(eq + 1));
            std::string k = line;
            if (k == "info_x") g_cfg.infoX = v;
            else if (k == "info_y") g_cfg.infoY = v;
            else if (k == "dx") g_cfg.dx = v;
            else if (k == "dy") g_cfg.dy = v;
        }
        fclose(f);
        return;
    }
    f = fopen(path.c_str(), "w");
    if (!f) return;
    fprintf(f,
            "# El disco se coloca solo junto a la barra de la musica de la pagina del nivel.\n"
            "# dx / dy: desplazamiento en puntos (dx positivo = derecha, dy positivo = arriba).\n"
            "# info_x / info_y: posicion de reserva (0..1) si no se encuentra la barra de la musica.\n"
            "# Reinicia el juego despues de editar.\n"
            "dx=%.1f\ndy=%.1f\ninfo_x=%.2f\ninfo_y=%.2f\n",
            g_cfg.dx, g_cfg.dy, g_cfg.infoX, g_cfg.infoY);
    fclose(f);
}

// ------------------------------------------------------------------ funciones de cocos2d (solo para ocultar/mostrar)
struct Sz { float w, h; };

static struct Cocos {
    void* (*getChildren)(void*) = nullptr;
    unsigned (*count)(void*) = nullptr;
    void* (*at)(void*, unsigned) = nullptr;
    bool (*isVisible)(void*) = nullptr;
    // para colocar el disco junto a la barra de la música (todas opcionales)
    void* (*getParent)(void*) = nullptr;
    const Sz* (*getContentSize)(void*) = nullptr;
    float (*getPosX)(void*) = nullptr;
    float (*getPosY)(void*) = nullptr;
    float (*getScaleX)(void*) = nullptr;
    float (*getScaleY)(void*) = nullptr;
    bool tried = false;
    bool ok = false;
    bool layoutOk = false;
} CC;

static bool resolveCocos() {
    if (CC.tried) return CC.ok;
    CC.tried = true;
    if (!A->find_symbol) return false;
    CC.getChildren = reinterpret_cast<void* (*)(void*)>(A->find_symbol("_ZN7cocos2d6CCNode11getChildrenEv"));
    CC.count = reinterpret_cast<unsigned (*)(void*)>(A->find_symbol("_ZNK7cocos2d7CCArray5countEv"));
    CC.at = reinterpret_cast<void* (*)(void*, unsigned)>(A->find_symbol("_ZN7cocos2d7CCArray13objectAtIndexEj"));
    void* vis = A->find_symbol("_ZN7cocos2d6CCNode9isVisibleEv");
    if (!vis) vis = A->find_symbol("_ZNK7cocos2d6CCNode9isVisibleEv");
    CC.isVisible = reinterpret_cast<bool (*)(void*)>(vis);
    CC.ok = CC.getChildren && CC.count && CC.at && CC.isVisible;
    CC.getParent = reinterpret_cast<void* (*)(void*)>(A->find_symbol("_ZN7cocos2d6CCNode9getParentEv"));
    void* gcs = A->find_symbol("_ZNK7cocos2d6CCNode14getContentSizeEv");
    if (!gcs) gcs = A->find_symbol("_ZN7cocos2d6CCNode14getContentSizeEv");
    CC.getContentSize = reinterpret_cast<const Sz* (*)(void*)>(gcs);
    CC.getPosX = reinterpret_cast<float (*)(void*)>(A->find_symbol("_ZN7cocos2d6CCNode12getPositionXEv"));
    CC.getPosY = reinterpret_cast<float (*)(void*)>(A->find_symbol("_ZN7cocos2d6CCNode12getPositionYEv"));
    CC.getScaleX = reinterpret_cast<float (*)(void*)>(A->find_symbol("_ZN7cocos2d6CCNode9getScaleXEv"));
    CC.getScaleY = reinterpret_cast<float (*)(void*)>(A->find_symbol("_ZN7cocos2d6CCNode9getScaleYEv"));
    CC.layoutOk = CC.getChildren && CC.count && CC.at && CC.getContentSize && CC.getPosX && CC.getPosY;
    logf(CC.ok ? ZFLIP_LOG_INFO : ZFLIP_LOG_WARN, "nongs: funciones de cocos2d para ocultar el menu: %s",
         CC.ok ? "OK" : "faltan (la ventana se dibujara encima sin ocultar el resto)");
    return CC.ok;
}

// ------------------------------------------------------------------ qué canción suena
static bool g_capture = false;             // true mientras se crea la página del nivel
static std::vector<std::string> g_infoKeys;

static void notePlayKey(const std::string& key) {
    logf(ZFLIP_LOG_DEBUG, "nongs: el juego pide la cancion %s", key.c_str());
}

static void noteInfoKey(const std::string& key) {
    if (!g_capture) return;
    if (std::find(g_infoKeys.begin(), g_infoKeys.end(), key) == g_infoKeys.end()) {
        g_infoKeys.push_back(key);
        logf(ZFLIP_LOG_INFO, "nongs: la pagina del nivel usa la cancion %s", key.c_str());
    }
}

// Canción de la página del nivel: se prefiere una personalizada (c<ID>) sobre una oficial (o<N>).
static std::string infoKey() {
    for (auto& k : g_infoKeys) if (!k.empty() && k[0] == 'c') return k;
    return g_infoKeys.empty() ? std::string() : g_infoKeys[0];
}

static std::string keyTitle(const std::string& key) {
    if (key.size() < 2) return "No detecte la cancion";
    if (key[0] == 'c') return "Cancion ID " + key.substr(1);
    return "Pista oficial " + key.substr(1);
}

// ------------------------------------------------------------------ interfaz
enum { kRows = 5 };

struct Ui {
    void* layer = nullptr;
    bool built = false;
    bool open = false;
    std::string key;
    int page = 0;
    int confirmDel = -1;
    std::vector<void*> win;        // nodos de la ventana
    std::vector<void*> hidden;     // nodos de la pantalla de fondo que ocultamos
    void* title = nullptr;
    void* sub = nullptr;
    void* pageLbl = nullptr;
    void* msg = nullptr;
    void* rowBtn[kRows] = {};
    void* rowDel[kRows] = {};
    int rowItem[kRows] = {-1, -1, -1, -1, -1};
    void* btnPrev = nullptr;
    void* btnNext = nullptr;
    void* btnAdd = nullptr;
    void* btnClose = nullptr;
    std::vector<std::string> files;
};
static Ui U;

static bool g_awaitPick = false;
static std::string g_pickKey;

static void show(void* n, bool v) { if (n && A->ui_set_visible) A->ui_set_visible(n, v ? 1 : 0); }
static void setColor(void* n, int r, int g, int b) {
    if (n && A->ui_set_color) A->ui_set_color(n, static_cast<uint8_t>(r), static_cast<uint8_t>(g), static_cast<uint8_t>(b));
}
static void setText(void* n, const std::string& t) { if (n && A->ui_set_text) A->ui_set_text(n, t.c_str()); }
static void setMsg(const std::string& t, int r = 170, int g = 170, int b = 190) {
    setText(U.msg, t);
    setColor(U.msg, r, g, b);
}

// Nombre corto y solo ASCII (la fuente del juego no tiene todos los caracteres).
static std::string shortName(const std::string& file) {
    std::string s = file;
    size_t d = s.rfind('.');
    if (d != std::string::npos && d > 0) s.resize(d);
    std::string o;
    for (unsigned char c : s) {
        if (c < 0x20) continue;
        if (c >= 0x80) {
            if (!o.empty() && o.back() == '?') continue;
            o += '?';
        } else {
            o += static_cast<char>(c);
        }
    }
    if (o.size() > 18) { o.resize(15); o += "..."; }
    if (o.empty()) o = "(sin nombre)";
    return o;
}

static int itemCount() { return U.key.empty() ? 0 : 1 + static_cast<int>(U.files.size()); }
static int pageCount() { int n = itemCount(); return n <= 0 ? 1 : (n + kRows - 1) / kRows; }

static void refresh() {
    U.files = listFiles(U.key);
    int pages = pageCount();
    if (U.page >= pages) U.page = pages - 1;
    if (U.page < 0) U.page = 0;
    std::string sel = getSelected(U.key);
    bool selValid = false;
    for (auto& f : U.files) if (f == sel) selValid = true;

    setText(U.sub, keyTitle(U.key));
    int n = itemCount();
    for (int r = 0; r < kRows; r++) {
        int idx = U.page * kRows + r;
        U.rowItem[r] = idx < n ? idx : -1;
        if (idx >= n) {
            show(U.rowBtn[r], false);
            show(U.rowDel[r], false);
            continue;
        }
        bool isOriginal = idx == 0;
        std::string name = isOriginal ? "Original" : shortName(U.files[idx - 1]);
        bool active = isOriginal ? !selValid : (U.files[idx - 1] == sel);
        setText(U.rowBtn[r], name);
        if (active) setColor(U.rowBtn[r], 90, 235, 120);
        else setColor(U.rowBtn[r], 255, 255, 255);
        show(U.rowBtn[r], true);
        if (isOriginal) {
            show(U.rowDel[r], false);
        } else {
            bool confirm = U.confirmDel == idx;
            setText(U.rowDel[r], confirm ? "Seguro?" : "X");
            setColor(U.rowDel[r], confirm ? 255 : 240, confirm ? 210 : 80, confirm ? 80 : 90);
            show(U.rowDel[r], true);
        }
    }
    char buf[32];
    snprintf(buf, sizeof(buf), "%d/%d", U.page + 1, pages);
    setText(U.pageLbl, buf);
    show(U.pageLbl, pages > 1);
    show(U.btnPrev, pages > 1);
    show(U.btnNext, pages > 1);
    show(U.btnAdd, !U.key.empty());
}

// --- ocultar el fondo mientras la ventana está abierta (así los toques no se «cuelan» a los botones de atrás)
static bool isWinNode(void* n) { return std::find(U.win.begin(), U.win.end(), n) != U.win.end(); }

static void hideOthers() {
    U.hidden.clear();
    if (!U.layer || !resolveCocos()) return;
    void* kids = CC.getChildren(U.layer);
    unsigned n = kids ? CC.count(kids) : 0;
    for (unsigned i = 0; i < n; i++) {
        void* c = CC.at(kids, i);
        if (!c || isWinNode(c)) continue;
        if (CC.isVisible(c)) {
            show(c, false);
            U.hidden.push_back(c);
        }
    }
    logf(ZFLIP_LOG_DEBUG, "nongs: %zu nodos de fondo ocultos", U.hidden.size());
}

static void restoreOthers() {
    for (void* c : U.hidden) show(c, true);
    U.hidden.clear();
}

static void showWin(bool v) { for (void* n : U.win) show(n, v); }

// --- callbacks de botones
static void closeWindow() {
    if (!U.open) return;
    guarded("cerrar ventana", [] {
        showWin(false);
        restoreOthers();
    });
    U.open = false;
    U.confirmDel = -1;
}

static void onClose(void*) { closeWindow(); }

static void onPrev(void*) { U.page--; U.confirmDel = -1; refresh(); }
static void onNext(void*) { U.page++; U.confirmDel = -1; refresh(); }

static void onRow(void* user) {
    int r = static_cast<int>(reinterpret_cast<intptr_t>(user));
    if (r < 0 || r >= kRows) return;
    int idx = U.rowItem[r];
    if (idx < 0) return;
    U.confirmDel = -1;
    if (idx == 0) {
        setSelected(U.key, "");
        setMsg("Original activa.");
    } else {
        const std::string& f = U.files[idx - 1];
        setSelected(U.key, f);
        setMsg("NONG activo.", 120, 235, 140);
        logf(ZFLIP_LOG_INFO, "nongs: %s -> %s", U.key.c_str(), f.c_str());
    }
    refresh();
}

static void onDel(void* user) {
    int r = static_cast<int>(reinterpret_cast<intptr_t>(user));
    if (r < 0 || r >= kRows) return;
    int idx = U.rowItem[r];
    if (idx <= 0) return;
    if (U.confirmDel != idx) {
        U.confirmDel = idx;
        refresh();
        return;
    }
    std::string f = U.files[idx - 1];
    unlink((keyDir(U.key) + "/" + f).c_str());
    if (getSelected(U.key) == f) setSelected(U.key, "");
    U.confirmDel = -1;
    setMsg("NONG borrado", 240, 120, 120);
    refresh();
}

// Abre el selector de archivos de Android (el mismo que usa el juego para importar niveles).
static bool openPicker() {
    JavaVM* vm = static_cast<JavaVM*>(A->java_vm);
    if (!vm) return false;
    JNIEnv* env = nullptr;
    bool attached = false;
    int r = vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6);
    if (r == JNI_EDETACHED) {
        #ifdef __ANDROID__
        if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return false;
#else
        if (vm->AttachCurrentThread(reinterpret_cast<void**>(&env), nullptr) != JNI_OK) return false;
#endif
        attached = true;
    } else if (r != JNI_OK) {
        return false;
    }
    bool ok = false;
    jclass c = env->FindClass("com/customRobTop/BaseRobTopActivity");
    if (!c) {
        env->ExceptionClear();
        logf(ZFLIP_LOG_ERROR, "nongs: no encuentro la clase BaseRobTopActivity");
    } else {
        jmethodID m = env->GetStaticMethodID(c, "pickImportFiles", "()V");
        if (!m) {
            env->ExceptionClear();
            logf(ZFLIP_LOG_ERROR, "nongs: no encuentro pickImportFiles()");
        } else {
            env->CallStaticVoidMethod(c, m);
            if (env->ExceptionCheck()) {
                env->ExceptionClear();
                logf(ZFLIP_LOG_ERROR, "nongs: pickImportFiles() lanzo una excepcion");
            } else {
                ok = true;
            }
        }
        env->DeleteLocalRef(c);
    }
    if (attached) vm->DetachCurrentThread();
    return ok;
}

static void onAdd(void*) {
    if (U.key.empty()) return;
    g_pickKey = U.key;
    g_awaitPick = true;
    U.confirmDel = -1;
    if (!openPicker()) {
        g_awaitPick = false;
        setMsg("No pude abrir el selector de archivos", 240, 120, 120);
        if (A->toast) A->toast("NONGs: no se pudo abrir el selector de archivos");
    } else {
        setMsg("Elige un audio (mp3, ogg, wav...)");
    }
}

// Mueve (o copia) un archivo elegido a la carpeta de la canción. Devuelve el nombre final o "".
static std::string importFile(const std::string& src, const std::string& key) {
    std::string name = baseName(src);
    if (!isAudioName(name)) {
        logf(ZFLIP_LOG_WARN, "nongs: se ignora %s (no es audio)", name.c_str());
        return "";
    }
    mkdirs(keyDir(key));
    std::string dstName = name;
    int counter = 2;
    while (existsPath(keyDir(key) + "/" + dstName)) dstName = std::to_string(counter++) + "_" + name;
    std::string dst = keyDir(key) + "/" + dstName;
    if (rename(src.c_str(), dst.c_str()) != 0) {
        if (!copyFile(src, dst)) {
            logf(ZFLIP_LOG_ERROR, "nongs: no se pudo copiar %s", src.c_str());
            return "";
        }
        unlink(src.c_str());
    }
    logf(ZFLIP_LOG_INFO, "nongs: agregado %s a %s", dstName.c_str(), key.c_str());
    return dstName;
}

// Hook de JniToCpp.filesPicked: si estamos esperando un archivo lo recibimos nosotros (y el juego no
// intenta importarlo como nivel); si no, todo sigue como siempre.
static void (*orig_filesPicked)(JNIEnv*, jclass, jobjectArray) = nullptr;
static void hook_filesPicked(JNIEnv* env, jclass cls, jobjectArray arr) {
    if (!g_awaitPick) {
        if (orig_filesPicked) orig_filesPicked(env, cls, arr);
        return;
    }
    g_awaitPick = false;
    jsize n = arr ? env->GetArrayLength(arr) : 0;
    std::string last;
    int added = 0;
    for (jsize i = 0; i < n; i++) {
        jstring s = static_cast<jstring>(env->GetObjectArrayElement(arr, i));
        if (!s) continue;
        const char* c = env->GetStringUTFChars(s, nullptr);
        if (c) {
            std::string nm = importFile(c, g_pickKey);
            if (!nm.empty()) { last = nm; added++; }
            env->ReleaseStringUTFChars(s, c);
        }
        env->DeleteLocalRef(s);
    }
    if (added > 0) setSelected(g_pickKey, last);
    if (U.layer && U.built && U.open && U.key == g_pickKey) {
        guarded("refrescar tras agregar", [&] {
            U.confirmDel = -1;
            if (added > 0) {
                // ir a la página del NONG nuevo
                std::vector<std::string> fs = listFiles(U.key);
                for (size_t k = 0; k < fs.size(); k++) if (fs[k] == last) U.page = static_cast<int>((k + 1) / kRows);
                setMsg(added == 1 ? "Agregado y activado" : "Agregados (ultimo activado)", 120, 235, 140);
            } else {
                setMsg("No se agrego nada (cancelado o no era audio)", 240, 170, 90);
            }
            refresh();
        });
    }
    if (added == 0 && A->toast) A->toast("NONGs: no se agrego ningun audio");
}

// --- construir la ventana (una vez por capa)
static void buildWindow() {
    float w = 0, h = 0;
    A->ui_win_size(&w, &h);
    if (!(w > 0 && h > 0)) { w = 569.f; h = 320.f; }
    const float cx = w / 2, cy = h / 2;
    void* L = U.layer;
    const int z = 3000;
    auto add = [&](void* n) { if (n) U.win.push_back(n); return n; };

    add(A->ui_rect(L, 0, 0, w, h, 0, 0, 0, 225, z));                               // oscurece todo
    add(A->ui_rect(L, cx - 184, cy - 144, 368, 288, 110, 80, 255, 255, z + 1));   // borde
    add(A->ui_rect(L, cx - 180, cy - 140, 360, 280, 22, 22, 40, 255, z + 2));     // panel

    U.title = add(A->ui_label(L, "NONGs", 0.65f, cx, cy + 116, z + 3));
    setColor(U.title, 255, 205, 70);
    U.sub = add(A->ui_label(L, "", 0.36f, cx, cy + 92, z + 3));
    setColor(U.sub, 150, 150, 175);
    U.pageLbl = add(A->ui_label(L, "1/1", 0.4f, cx - 122, cy - 100, z + 3));
    U.msg = add(A->ui_label(L, "", 0.3f, cx, cy - 124, z + 3));

    void* menu = add(A->ui_menu(L, z + 4));
    if (!menu) { logf(ZFLIP_LOG_ERROR, "nongs: no se pudo crear el menu de la ventana"); return; }

    for (int r = 0; r < kRows; r++) {
        float y = cy + 64.f - r * 32.f;
        // el texto de relleno fija el tamaño del botón (zona táctil); luego se cambia el texto
        U.rowBtn[r] = A->ui_button(menu, "WWWWWWWWWWWWWW", 0.42f, cx - 20, y, onRow, reinterpret_cast<void*>(static_cast<intptr_t>(r)));
        U.rowDel[r] = A->ui_button(menu, "Seguro?", 0.36f, cx + 140, y, onDel, reinterpret_cast<void*>(static_cast<intptr_t>(r)));
    }
    U.btnPrev = A->ui_button(menu, "<", 0.6f, cx - 150, cy - 100, onPrev, nullptr);
    U.btnNext = A->ui_button(menu, ">", 0.6f, cx - 94, cy - 100, onNext, nullptr);
    U.btnAdd = A->ui_button(menu, "+ Agregar", 0.5f, cx + 28, cy - 100, onAdd, nullptr);
    setColor(U.btnAdd, 90, 235, 120);
    U.btnClose = A->ui_button(menu, "Cerrar", 0.5f, cx + 125, cy - 100, onClose, nullptr);
    setColor(U.btnClose, 240, 90, 100);
    U.built = true;
    logf(ZFLIP_LOG_INFO, "nongs: ventana creada (%.0f x %.0f)", w, h);
}

static void openWindow() {
    if (U.open || !U.layer) return;
    U.key = infoKey();
    logf(ZFLIP_LOG_INFO, "nongs: abriendo ventana, cancion=%s", U.key.empty() ? "(no detectada)" : U.key.c_str());
    bool ok = guarded("abrir ventana", [] {
        if (!U.built) buildWindow();
        if (!U.built) return;
        hideOthers();
        showWin(true);
        U.open = true;
        U.page = 0;
        U.confirmDel = -1;
        refresh();
        if (U.key.empty()) setMsg("No detecte la cancion de este nivel", 240, 170, 90);
        else setMsg("");
    });
    if (!ok) {
        logf(ZFLIP_LOG_ERROR, "nongs: la ventana fallo al abrirse");
        if (A->toast) A->toast("NONGs: error al abrir la ventana (mira los Registros)");
    }
}

static void onDisc(void*) { openWindow(); }

static void resetUi(void* layer) {
    U = Ui();
    U.layer = layer;
}

// ------------------------------------------------------------------ colocación junto a la música
// Nombre de clase (mangled, p. ej. "16CustomSongWidget") leído del RTTI del objeto.
static std::string className(void* node) {
    char buf[96] = {0};
    guarded("RTTI", [&] {
        void** vt = *reinterpret_cast<void***>(node);
        if (!vt) return;
        void** ti = reinterpret_cast<void**>(vt[-1]);
        if (!ti) return;
        const char* nm = reinterpret_cast<const char*>(ti[1]);
        if (nm) strncpy(buf, nm, sizeof(buf) - 1);
    });
    return buf;
}

static bool isSongWidget(void* node, void* songVtable) {
    bool match = false;
    guarded("vtable", [&] {
        if (songVtable && *reinterpret_cast<void**>(node) == songVtable) match = true;
    });
    return match || className(node).find("CustomSongWidget") != std::string::npos;
}

static void* findSongWidget(void* layer) {
    if (!resolveCocos() || !CC.layoutOk) return nullptr;
    void* tv = A->find_symbol("_ZTV16CustomSongWidget");
    void* vt = tv ? static_cast<char*>(tv) + 2 * sizeof(void*) : nullptr;   // vptr = &vtable + 16 (ABI Itanium)
    void* kids = CC.getChildren(layer);
    unsigned n = kids ? CC.count(kids) : 0;
    for (unsigned i = 0; i < n; i++) {
        void* c = CC.at(kids, i);
        if (c && isSongWidget(c, vt)) return c;
    }
    return nullptr;
}

struct Box { float l = 1e9f, b = 1e9f, r = -1e9f, t = -1e9f; bool ok = false; };

// Rectángulo que ocupa la barra de la música, en coordenadas de su padre (asumiendo anclas centradas,
// que es lo que usan los sprites y etiquetas del juego).
static bool songBounds(void* widget, float winW, Box& out) {
    void* kids = CC.getChildren(widget);
    unsigned n = kids ? CC.count(kids) : 0;
    float ws = CC.getScaleX ? CC.getScaleX(widget) : 1.f;
    if (!(ws > 0.01f && ws < 20.f)) ws = 1.f;
    for (unsigned i = 0; i < n; i++) {
        void* c = CC.at(kids, i);
        if (!c) continue;
        std::string nm = className(c);
        if (nm.find("CCMenu") != std::string::npos) continue;          // los menús miden como toda la pantalla
        const Sz* sz = CC.getContentSize(c);
        if (!sz || !(sz->w > 1.f && sz->h > 1.f) || sz->w > winW * 0.9f) continue;
        float sx = CC.getScaleX ? CC.getScaleX(c) : 1.f, sy = CC.getScaleY ? CC.getScaleY(c) : 1.f;
        float px = CC.getPosX(c), py = CC.getPosY(c);
        float hw = sz->w * sx / 2, hh = sz->h * sy / 2;
        out.l = std::min(out.l, px - hw);
        out.r = std::max(out.r, px + hw);
        out.b = std::min(out.b, py - hh);
        out.t = std::max(out.t, py + hh);
        out.ok = true;
    }
    if (out.ok) {
        out.l *= ws; out.r *= ws; out.b *= ws; out.t *= ws;
    }
    return out.ok;
}

// Vuelca el árbol de la página del nivel al registro (nivel DEBUG) para poder ajustar la posición.
static void dumpInfoLayer(void* layer) {
    if (!resolveCocos() || !CC.layoutOk) return;
    void* kids = CC.getChildren(layer);
    unsigned n = kids ? CC.count(kids) : 0;
    logf(ZFLIP_LOG_DEBUG, "nongs: LevelInfoLayer %p tiene %u hijos", layer, n);
    for (unsigned i = 0; i < n && i < 40; i++) {
        void* c = CC.at(kids, i);
        if (!c) continue;
        const Sz* sz = CC.getContentSize(c);
        void* ck = CC.getChildren(c);
        logf(ZFLIP_LOG_DEBUG, "nongs:   [%u] %s pos=(%.1f, %.1f) tam=(%.1f x %.1f) hijos=%u", i,
             className(c).c_str(), CC.getPosX(c), CC.getPosY(c), sz ? sz->w : 0.f, sz ? sz->h : 0.f,
             ck ? CC.count(ck) : 0u);
    }
}

// Calcula dónde poner el disco: pegado a la barra de la música (a su derecha; si no cabe, a su
// izquierda). Si no se encuentra la barra, usa la posición de reserva del config.txt.
// parent = nodo donde se dibujará (el padre de la barra de la música, para compartir coordenadas).
static void placeDisc(void* layer, void*& parent, float& x, float& y) {
    float w = 0, h = 0;
    A->ui_win_size(&w, &h);
    if (!(w > 0 && h > 0)) { w = 569.f; h = 320.f; }
    parent = layer;
    x = w * g_cfg.infoX + g_cfg.dx;
    y = h * g_cfg.infoY + g_cfg.dy;

    void* outParent = layer;
    float outX = 0, outY = 0;
    bool placed = false;
    guarded("buscar barra de la musica", [&] {
        dumpInfoLayer(layer);
        void* widget = findSongWidget(layer);
        if (!widget) {
            logf(ZFLIP_LOG_WARN, "nongs: no encontre la barra de la musica; uso la posicion de reserva");
            return;
        }
        void* par = CC.getParent ? CC.getParent(widget) : nullptr;
        if (!par) par = layer;
        float wx = CC.getPosX(widget), wy = CC.getPosY(widget);
        float ws = CC.getScaleX ? CC.getScaleX(widget) : 1.f;
        if (!(ws > 0.01f && ws < 20.f)) ws = 1.f;
        Box bx;
        if (!songBounds(widget, w, bx)) {
            logf(ZFLIP_LOG_WARN, "nongs: la barra de la musica no tiene medidas legibles; uso la posicion de reserva");
            return;
        }
        float left = wx + bx.l, right = wx + bx.r, midY = wy + (bx.b + bx.t) / 2;
        logf(ZFLIP_LOG_INFO, "nongs: barra de la musica %p en (%.1f, %.1f), x=[%.1f, %.1f], y=%.1f, escala %.2f",
             widget, wx, wy, left, right, midY, ws);
        const float gap = 26.f;
        float cand = right + gap;
        if (cand > w - 18.f) cand = left - gap;                       // no cabe a la derecha: a la izquierda
        if (cand < 18.f || cand > w - 14.f) {
            logf(ZFLIP_LOG_WARN, "nongs: no hay sitio junto a la barra (x=%.1f); uso la posicion de reserva", cand);
            return;
        }
        outParent = par;
        outX = cand;
        outY = midY;
        placed = true;
    });
    if (placed) {
        parent = outParent;
        x = outX + g_cfg.dx;
        y = outY + g_cfg.dy;
    }
}

// Disco (círculo) pulsable + rótulo. No se ajusta la prioridad táctil (falla en GD 2.2091).
static void buildDisc(void* layer) {
    void* parent = layer;
    float x = 0, y = 0;
    placeDisc(layer, parent, x, y);
    void* menu = A->ui_menu(parent, 1500);
    if (!menu) { logf(ZFLIP_LOG_ERROR, "nongs: no se pudo crear el menu del disco"); return; }
    void* disc = A->ui_button(menu, "O", 0.95f, x, y, onDisc, nullptr);
    setColor(disc, 190, 120, 255);
    void* cap = A->ui_label(parent, "NONG", 0.24f, x, y - 22.f, 1501);
    setColor(cap, 190, 150, 255);
    logf(ZFLIP_LOG_INFO, "nongs: disco creado en (%.0f, %.0f) [pagina del nivel]", x, y);
}

// ------------------------------------------------------------------ eventos
static bool (*orig_LevelInfoLayer_init)(void*, void*, bool) = nullptr;
static bool hook_LevelInfoLayer_init(void* self, void* level, bool challenge) {
    g_infoKeys.clear();
    g_capture = true;
    bool r = orig_LevelInfoLayer_init(self, level, challenge);
    g_capture = false;
    if (r) {
        guarded("disco en la pagina del nivel", [&] {
            resetUi(self);
            buildDisc(self);
        });
    }
    return r;
}

// ------------------------------------------------------------------ cambio de música
static std::string (*orig_getAudioFileName)(int) = nullptr;
static std::string hook_getAudioFileName(int id) {
    std::string key = "o" + std::to_string(id);
    notePlayKey(key);
    std::string p;
    if (pathFor(key, p)) return p;
    return orig_getAudioFileName(id);
}

static std::string (*orig_pathForSong)(void*, int) = nullptr;
static std::string hook_pathForSong(void* self, int id) {
    std::string key = "c" + std::to_string(id);
    notePlayKey(key);
    std::string p;
    if (pathFor(key, p)) return p;
    return orig_pathForSong(self, id);
}

// Si el original no está descargado pero hay un NONG activo, el juego debe creer que sí lo está.
static bool (*orig_isSongDownloaded)(void*, int) = nullptr;
static bool hook_isSongDownloaded(void* self, int id) {
    std::string p;
    if (pathFor("c" + std::to_string(id), p)) return true;
    return orig_isSongDownloaded(self, id);
}

// Solo para saber qué canción usa la página del nivel.
static void* (*orig_getSongInfoObject)(void*, int) = nullptr;
static void* hook_getSongInfoObject(void* self, int id) {
    if (id > 0) noteInfoKey("c" + std::to_string(id));
    return orig_getSongInfoObject(self, id);
}

static std::string (*orig_getAudioTitle)(int) = nullptr;
static std::string hook_getAudioTitle(int id) {
    noteInfoKey("o" + std::to_string(id));
    return orig_getAudioTitle(id);
}

static bool hookOne(const char* sym, void* detour, void** orig, bool required) {
    int rc = A->hook_symbol(sym, detour, orig);
    if (rc != 0) {
        logf(required ? ZFLIP_LOG_ERROR : ZFLIP_LOG_WARN, "nongs: no se pudo enganchar %s", sym);
        *orig = nullptr;
        return false;
    }
    logf(ZFLIP_LOG_INFO, "nongs: enganchado %s", sym);
    return true;
}

extern "C" __attribute__((visibility("default"))) int zflip_main(const ZflipApi* api) {
    A = api;
    api->log(ZFLIP_LOG_INFO, "nongs: cargado");
    if (api->struct_size < offsetof(ZflipApi, ui_set_visible) + sizeof(api->ui_set_visible) || !api->find_symbol ||
        !api->ui_win_size || !api->ui_rect || !api->ui_label || !api->ui_menu || !api->ui_button ||
        !api->ui_set_text || !api->ui_set_visible) {
        api->log(ZFLIP_LOG_ERROR, "nongs: este launcher es demasiado antiguo (se necesita API v2 o superior)");
        return 1;
    }

    g_dataDir = api->data_dir;
    g_root = g_dataDir + "/nongs";
    mkdirs(g_root);
    loadSelected();
    loadConfig();
    installGuard();

    // música: estos dos son imprescindibles
    bool a = hookOne("_ZN10LevelTools16getAudioFileNameEi", reinterpret_cast<void*>(hook_getAudioFileName),
                     reinterpret_cast<void**>(&orig_getAudioFileName), true);
    bool b = hookOne("_ZN20MusicDownloadManager11pathForSongEi", reinterpret_cast<void*>(hook_pathForSong),
                     reinterpret_cast<void**>(&orig_pathForSong), true);
    if (!a && !b) {
        api->log(ZFLIP_LOG_ERROR, "nongs: no se pudo enganchar ninguna funcion de musica; el mod no hara nada");
        return 1;
    }
    hookOne("_ZN20MusicDownloadManager16isSongDownloadedEi", reinterpret_cast<void*>(hook_isSongDownloaded),
            reinterpret_cast<void**>(&orig_isSongDownloaded), false);

    // opcionales: mejoran la deteccion de la cancion y agregan el disco en la pagina del nivel
    hookOne("_ZN20MusicDownloadManager17getSongInfoObjectEi", reinterpret_cast<void*>(hook_getSongInfoObject),
            reinterpret_cast<void**>(&orig_getSongInfoObject), false);
    hookOne("_ZN10LevelTools13getAudioTitleEi", reinterpret_cast<void*>(hook_getAudioTitle),
            reinterpret_cast<void**>(&orig_getAudioTitle), false);
    hookOne("_ZN14LevelInfoLayer4initEP11GJGameLevelb", reinterpret_cast<void*>(hook_LevelInfoLayer_init),
            reinterpret_cast<void**>(&orig_LevelInfoLayer_init), false);

    // el boton «+»: recibir el archivo que elige el usuario
    if (!hookOne("Java_com_customRobTop_JniToCpp_filesPicked", reinterpret_cast<void*>(hook_filesPicked),
                 reinterpret_cast<void**>(&orig_filesPicked), false)) {
        api->log(ZFLIP_LOG_WARN, "nongs: el boton + no funcionara; copia los audios a mano a la carpeta del mod");
    }
    return 0;
}
