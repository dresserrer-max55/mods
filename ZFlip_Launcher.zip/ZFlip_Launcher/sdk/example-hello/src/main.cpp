// Mod de ejemplo: «Mini Mod Menu».
//
// Aparece en dos sitios:
//  - sobre la pantalla de carga (panel abierto), y
//  - en el MENÚ DE PAUSA de los niveles (pestaña «[ZFlip]» arriba a la izquierda; púlsala para abrir).
//
// Opciones:
//  - Noclip: no mueres al chocar (engancha PlayLayer::destroyPlayer).
//  - Velocidad del juego (0.5x / 1x / 1.5x / 2x), si el juego lo permite.
//  - Aviso en menú: un toast al abrir el menú principal.
//
// Los ajustes se guardan en <data_dir>/settings.txt.
#include <cstdio>
#include <cstring>
#include <string>

#include "zflip.h"

static const ZflipApi* g_api = nullptr;

// ------------------------------------------------------------------ ajustes
static bool g_toastOnMenu = true;
static bool g_noclip = false;
static int g_speedIdx = 1;
static const float kSpeeds[] = {0.5f, 1.0f, 1.5f, 2.0f};
static const char* kSpeedText[] = {"Velocidad: 0.5x", "Velocidad: 1.0x", "Velocidad: 1.5x", "Velocidad: 2.0x"};

static std::string settingsPath() { return std::string(g_api->data_dir) + "/settings.txt"; }

static void loadSettings() {
    FILE* f = fopen(settingsPath().c_str(), "r");
    if (!f) return;
    int t = 1, s = 1, n = 0;
    if (fscanf(f, "toast=%d\nspeed=%d\nnoclip=%d", &t, &s, &n) >= 1) {
        g_toastOnMenu = t != 0;
        if (s >= 0 && s < 4) g_speedIdx = s;
        g_noclip = n != 0;
    }
    fclose(f);
}

static void saveSettings() {
    FILE* f = fopen(settingsPath().c_str(), "w");
    if (!f) return;
    fprintf(f, "toast=%d\nspeed=%d\nnoclip=%d\n", g_toastOnMenu ? 1 : 0, g_speedIdx, g_noclip ? 1 : 0);
    fclose(f);
}

// ------------------------------------------------------------------ interfaz
// (solo hay un panel visible a la vez: el de la capa actual)
static void* g_panelRect = nullptr;
static void* g_panelTitle = nullptr;
static void* g_panelMenu = nullptr;
static void* g_tabMenu = nullptr;
static void* g_btnNoclip = nullptr;
static void* g_btnToast = nullptr;
static void* g_btnSpeed = nullptr;

static void paintToggle(void* btn, const char* onText, const char* offText, bool on) {
    if (!btn) return;
    g_api->ui_set_text(btn, on ? onText : offText);
    if (g_api->ui_set_color) {
        if (on) g_api->ui_set_color(btn, 90, 220, 120);
        else g_api->ui_set_color(btn, 235, 90, 100);
    }
}

static void refreshNoclip() { paintToggle(g_btnNoclip, "Noclip: ON", "Noclip: OFF", g_noclip); }
static void refreshToast() { paintToggle(g_btnToast, "Aviso en menu: ON", "Aviso en menu: OFF", g_toastOnMenu); }

static void applySpeed() {
    if (!g_btnSpeed) return;
    if (g_api->set_time_scale && g_api->set_time_scale(kSpeeds[g_speedIdx]) == 0) {
        g_api->ui_set_text(g_btnSpeed, kSpeedText[g_speedIdx]);
        if (g_api->ui_set_color) {
            if (g_speedIdx == 1) g_api->ui_set_color(g_btnSpeed, 255, 255, 255);
            else g_api->ui_set_color(g_btnSpeed, 255, 210, 90);
        }
    } else {
        g_api->ui_set_text(g_btnSpeed, "Velocidad: no disponible");
        if (g_api->ui_set_color) g_api->ui_set_color(g_btnSpeed, 150, 150, 160);
    }
}

static void onToggleNoclip(void*) {
    g_noclip = !g_noclip;
    refreshNoclip();
    saveSettings();
    g_api->log(ZFLIP_LOG_INFO, g_noclip ? "noclip: ON" : "noclip: OFF");
}

static void onToggleToast(void*) {
    g_toastOnMenu = !g_toastOnMenu;
    refreshToast();
    saveSettings();
}

static void onSpeed(void*) {
    g_speedIdx = (g_speedIdx + 1) % 4;
    applySpeed();
    saveSettings();
    g_api->log(ZFLIP_LOG_INFO, kSpeedText[g_speedIdx]);
}

static void setPanelVisible(bool v) {
    g_api->ui_set_visible(g_panelRect, v);
    g_api->ui_set_visible(g_panelTitle, v);
    g_api->ui_set_visible(g_panelMenu, v);
    g_api->ui_set_visible(g_tabMenu, !v);
}

static void onHide(void*) { setPanelVisible(false); }
static void onShow(void*) { setPanelVisible(true); }

static bool haveUi() {
    return g_api->struct_size >= sizeof(ZflipApi) && g_api->ui_win_size && g_api->ui_rect &&
           g_api->ui_label && g_api->ui_menu && g_api->ui_button && g_api->ui_set_text &&
           g_api->ui_set_visible;
}

// startOpen: abierto al crearse. touchPriority: 0 = por defecto; en la pausa hace falta uno más alto.
static void buildMenu(void* layer, bool startOpen, int touchPriority, const char* where) {
    float w = 0, h = 0;
    g_api->ui_win_size(&w, &h);
    if (h <= 0) h = 320.f;
    const float pw = 190.f, ph = 140.f, x0 = 8.f, y0 = h - 8.f - ph;
    const float cx = x0 + pw / 2;
    const int z = 1000;

    g_panelRect = g_api->ui_rect(layer, x0, y0, pw, ph, 0, 0, 0, 190, z);
    g_panelTitle = g_api->ui_label(layer, "ZFlip Mini Menu", 0.42f, cx, y0 + ph - 14.f, z + 1);
    if (g_api->ui_set_color && g_panelTitle) g_api->ui_set_color(g_panelTitle, 140, 130, 255);

    g_panelMenu = g_api->ui_menu(layer, z + 2);
    g_tabMenu = g_api->ui_menu(layer, z + 2);
    if (touchPriority != 0 && g_api->ui_menu_priority) {
        g_api->ui_menu_priority(g_panelMenu, touchPriority);
        g_api->ui_menu_priority(g_tabMenu, touchPriority);
    }

    g_btnNoclip = g_api->ui_button(g_panelMenu, "Noclip: OFF", 0.36f, cx, y0 + ph - 40.f, onToggleNoclip, nullptr);
    g_btnSpeed = g_api->ui_button(g_panelMenu, "Velocidad: 1.0x", 0.36f, cx, y0 + ph - 66.f, onSpeed, nullptr);
    g_btnToast = g_api->ui_button(g_panelMenu, "Aviso en menu: ON", 0.36f, cx, y0 + ph - 92.f, onToggleToast, nullptr);
    g_api->ui_button(g_panelMenu, "Ocultar", 0.36f, cx, y0 + ph - 118.f, onHide, nullptr);
    g_api->ui_button(g_tabMenu, "[ZFlip]", 0.4f, 38.f, h - 14.f, onShow, nullptr);

    refreshNoclip();
    refreshToast();
    applySpeed();
    setPanelVisible(startOpen);
    std::string msg = std::string("mini menu creado en ") + where;
    g_api->log(ZFLIP_LOG_INFO, msg.c_str());
}

// ------------------------------------------------------------------ eventos
static void onLoadingLayer(void* layer) {
    if (haveUi()) buildMenu(layer, true, 0, "la pantalla de carga");
    else g_api->log(ZFLIP_LOG_WARN, "mini menu: el juego no ofrece la API de interfaz");
}

static void onPauseLayer(void* layer) {
    if (haveUi()) buildMenu(layer, false, -600, "el menu de pausa");
}

static void onMenuLayer(void*) {
    if (g_toastOnMenu) g_api->toast("ZFlip Mini Menu activo");
}

// ------------------------------------------------------------------ noclip
static void (*orig_destroyPlayer)(void*, void*, void*) = nullptr;
static void hook_destroyPlayer(void* self, void* player, void* object) {
    if (g_noclip) return;   // no morir
    orig_destroyPlayer(self, player, object);
}

extern "C" __attribute__((visibility("default"))) int zflip_main(const ZflipApi* api) {
    g_api = api;
    api->log(ZFLIP_LOG_INFO, "mini menu: cargado");
    loadSettings();

    // ZFlip engancha estas capas por ti (API v3/v4); no las enganches tú.
    if (api->struct_size < sizeof(ZflipApi) || !api->on_loading_layer || !api->on_menu_layer ||
        !api->on_pause_layer) {
        api->log(ZFLIP_LOG_ERROR, "mini menu: este launcher es demasiado antiguo (se necesita API v4)");
        return 1;
    }
    int ok = 0;
    if (api->on_loading_layer(onLoadingLayer) != 0) { api->log(ZFLIP_LOG_ERROR, "mini menu: sin evento de carga"); ok++; }
    if (api->on_menu_layer(onMenuLayer) != 0) { api->log(ZFLIP_LOG_ERROR, "mini menu: sin evento de menu"); ok++; }
    if (api->on_pause_layer(onPauseLayer) != 0) { api->log(ZFLIP_LOG_ERROR, "mini menu: sin evento de pausa"); ok++; }

    if (api->hook_symbol("_ZN9PlayLayer13destroyPlayerEP12PlayerObjectP10GameObject",
                         reinterpret_cast<void*>(hook_destroyPlayer),
                         reinterpret_cast<void**>(&orig_destroyPlayer)) != 0) {
        api->log(ZFLIP_LOG_ERROR, "mini menu: no se pudo enganchar PlayLayer::destroyPlayer (noclip no funcionara)");
    }
    return ok == 3 ? 1 : 0;
}
