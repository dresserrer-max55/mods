# Mini Mod Menu (hello) 3.1.0

Panel «ZFlip Mini Menu» sobre la pantalla de carga y en la pausa (pestaña `[ZFlip]` arriba a la izquierda).

* **Noclip**: no mueres al chocar.
* **Velocidad** 0.5x / 1x / 1.5x / 2x: engancha `CCScheduler::update(float)` y multiplica el dt. `setTimeScale` es inline en
  cocos2d-x y GD 2.2091 no la exporta, por eso antes ponía «no disponible».
* **Desbloquear todo**: todos los iconos y colores aparecen desbloqueados en el selector (solo visual/local; no cambia tu
  progreso guardado). Tras activarlo, vuelve a abrir el selector de iconos. Engancha `GameManager::isIconUnlocked`,
  `GameManager::isColorUnlocked` y `GameStatsManager::isItemUnlocked`; si ninguna existe en tu versión, el botón dice
  «no disponible» (en Registros aparece cuál se enganchó).
* **Aviso en menú**: toast al abrir el menú principal.

Ajustes en `.../moddata/hello/settings.txt`.
