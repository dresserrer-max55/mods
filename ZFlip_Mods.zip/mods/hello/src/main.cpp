// Mod «Mini Mod Menu» para ZFlip (Geometry Dash 2.2091).
//
// Aparece en dos sitios:
//  - sobre la pantalla de carga (panel abierto), y
//  - en el MENÚ DE PAUSA de los niveles (pestaña «[ZFlip]» arriba a la izquierda; púlsala para abrir).
//
// Opciones:
//  - Noclip: no mueres al chocar (engancha PlayLayer::destroyPlayer).
//  - Velocidad del juego (0.5x / 1x / 1.5x / 2x). Se hace enganchando CCScheduler::update(float) y
//    multiplicando el dt. (CCScheduler::setTimeScale es inline en cocos2d-x: GD no lo exporta, por eso
//    api->set_time_scale devuelve -1 en esta versión; solo se usa como respaldo.)
//  - Desbloquear todo: todos los iconos (cubo, nave, bola, UFO, wave, robot, spider, swing, jetpack)
//    y todos los colores aparecen desbloqueados en el selector. Es solo visual/local: no modifica tu
//    progreso guardado ni logros, y al apagarlo vuelve a mostrarse lo que realmente tienes.
//  - Aviso en menú: un toast al abrir el menú principal.
//
// Los ajustes se guardan en <data_dir>/settings.txt.
#include <cstdio>
#include <cstring>
#include <string>

#include "zflip.h"

static const ZflipApi* g_api = nullptr;

// ------------------------------------------------------------------ ajustes
static bool g_toastOnMenu = true;
static bool g_noclip = false;
static bool g_unlockAll = false;
static int g_speedIdx = 1;
static const float kSpeeds[] = {0.5f, 1.0f, 1.5f, 2.0f};
static const char* kSpeedText[] = {"Velocidad: 0.5x", "Velocidad: 1.0x", "Velocidad: 1.5x", "Velocidad: 2.0x"};

static std::string settingsPath() { return std::string(g_api->data_dir) + "/settings.txt"; }

static void loadSettings() {
    FILE* f = fopen(settingsPath().c_str(), "r");
    if (!f) return;
    int t = 1, s = 1, n = 0, u = 0;
    int got = fscanf(f, "toast=%d\nspeed=%d\nnoclip=%d\nunlock=%d", &t, &s, &n, &u);
    if (got >= 1) {
        g_toastOnMenu = t != 0;
        if (got >= 2 && s >= 0 && s < 4) g_speedIdx = s;
        if (got >= 3) g_noclip = n != 0;
        if (got >= 4) g_unlockAll = u != 0;
    }
    fclose(f);
}

static void saveSettings() {
    FILE* f = fopen(settingsPath().c_str(), "w");
    if (!f) return;
    fprintf(f, "toast=%d\nspeed=%d\nnoclip=%d\nunlock=%d\n", g_toastOnMenu ? 1 : 0, g_speedIdx, g_noclip ? 1 : 0,
            g_unlockAll ? 1 : 0);
    fclose(f);
}

// ------------------------------------------------------------------ velocidad
// Factor que se aplica al dt de cada fotograma. Se lee desde el hilo del juego; un float alineado se
// escribe de forma atómica en ARM, así que no hace falta nada más.
static volatile float g_speed = 1.0f;
static bool g_speedHooked = false;

static void (*orig_schedUpdate)(void*, float) = nullptr;
static void hook_schedUpdate(void* self, float dt) {
    if (!orig_schedUpdate) return;   // el gancho se acaba de instalar y aún no hay original
    orig_schedUpdate(self, dt * g_speed);
}

// true si hay algún método para cambiar la velocidad.
static bool speedAvailable() {
    return g_speedHooked || g_api->set_time_scale;
}

// Aplica la velocidad elegida. Devuelve true si se pudo.
static bool setGameSpeed(float s) {
    if (g_speedHooked) {
        g_speed = s;
        return true;
    }
    return g_api->set_time_scale && g_api->set_time_scale(s) == 0;
}

// ------------------------------------------------------------------ desbloquear todo
// Tipos del juego (enums de GD 2.2):
//   IconType:   0 cubo, 1 nave, 2 bola, 3 UFO, 4 wave, 5 robot, 6 spider, 7 swing, 8 jetpack
//   UnlockType: 1 cubo, 2 color 1, 3 color 2, 4 nave, 5 bola, 6 UFO, 7 wave, 8 robot, 9 spider,
//               13 swing, 14 jetpack (10 estela, 11 explosión, 12 objeto de tienda, 15 fuego: NO se tocan)
static int g_unlockHooks = 0;

static bool (*orig_isIconUnlocked)(void*, int, int) = nullptr;
static bool hook_isIconUnlocked(void* self, int id, int type) {
    if (g_unlockAll && type >= 0 && type <= 8) return true;
    return orig_isIconUnlocked(self, id, type);
}

static bool (*orig_isColorUnlocked)(void*, int, int) = nullptr;
static bool hook_isColorUnlocked(void* self, int id, int type) {
    if (g_unlockAll) return true;
    return orig_isColorUnlocked(self, id, type);
}

// GameStatsManager::isItemUnlocked(UnlockType, int): el selector de iconos también pasa por aquí.
static bool (*orig_isItemUnlocked)(void*, int, int) = nullptr;
static bool hook_isItemUnlocked(void* self, int type, int id) {
    if (g_unlockAll && ((type >= 1 && type <= 9) || type == 13 || type == 14)) return true;
    return orig_isItemUnlocked(self, type, id);
}

// ------------------------------------------------------------------ interfaz
// (solo hay un panel visible a la vez: el de la capa actual)
static void* g_panelRect = nullptr;
static void* g_panelTitle = nullptr;
static void* g_panelMenu = nullptr;
static void* g_tabMenu = nullptr;
static void* g_btnNoclip = nullptr;
static void* g_btnToast = nullptr;
static void* g_btnSpeed = nullptr;
static void* g_btnUnlock = nullptr;

static void paintToggle(void* btn, const char* onText, const char* offText, bool on) {
    if (!btn) return;
    g_api->ui_set_text(btn, on ? onText : offText);
    if (g_api->ui_set_color) {
        if (on) g_api->ui_set_color(btn, 90, 220, 120);
        else g_api->ui_set_color(btn, 235, 90, 100);
    }
}

static void refreshNoclip() { paintToggle(g_btnNoclip, "Noclip: ON", "Noclip: OFF", g_noclip); }
static void refreshToast() { paintToggle(g_btnToast, "Aviso en menu: ON", "Aviso en menu: OFF", g_toastOnMenu); }

static void refreshUnlock() {
    if (!g_btnUnlock) return;
    if (g_unlockHooks == 0) {
        g_api->ui_set_text(g_btnUnlock, "Desbloquear: no disponible");
        if (g_api->ui_set_color) g_api->ui_set_color(g_btnUnlock, 150, 150, 160);
        return;
    }
    paintToggle(g_btnUnlock, "Desbloquear todo: ON", "Desbloquear todo: OFF", g_unlockAll);
}

static void refreshSpeed() {
    if (!g_btnSpeed) return;
    if (speedAvailable()) {
        g_api->ui_set_text(g_btnSpeed, kSpeedText[g_speedIdx]);
        if (g_api->ui_set_color) {
            if (g_speedIdx == 1) g_api->ui_set_color(g_btnSpeed, 255, 255, 255);
            else g_api->ui_set_color(g_btnSpeed, 255, 210, 90);
        }
    } else {
        g_api->ui_set_text(g_btnSpeed, "Velocidad: no disponible");
        if (g_api->ui_set_color) g_api->ui_set_color(g_btnSpeed, 150, 150, 160);
    }
}

static void onToggleNoclip(void*) {
    g_noclip = !g_noclip;
    refreshNoclip();
    saveSettings();
    g_api->log(ZFLIP_LOG_INFO, g_noclip ? "noclip: ON" : "noclip: OFF");
}

static void onToggleToast(void*) {
    g_toastOnMenu = !g_toastOnMenu;
    refreshToast();
    saveSettings();
}

static void onToggleUnlock(void*) {
    if (g_unlockHooks == 0) {
        if (g_api->toast) g_api->toast("Desbloquear todo: el juego no ofrece esas funciones (mira Registros)");
        return;
    }
    g_unlockAll = !g_unlockAll;
    refreshUnlock();
    saveSettings();
    g_api->log(ZFLIP_LOG_INFO, g_unlockAll ? "desbloquear todo: ON" : "desbloquear todo: OFF");
    if (g_api->toast) g_api->toast(g_unlockAll ? "Todo desbloqueado. Reabre el selector de iconos"
                                                : "Desbloqueo apagado. Reabre el selector de iconos");
}

static void onSpeed(void*) {
    g_speedIdx = (g_speedIdx + 1) % 4;
    setGameSpeed(kSpeeds[g_speedIdx]);
    refreshSpeed();
    saveSettings();
    g_api->log(ZFLIP_LOG_INFO, kSpeedText[g_speedIdx]);
}

static void setPanelVisible(bool v) {
    g_api->ui_set_visible(g_panelRect, v);
    g_api->ui_set_visible(g_panelTitle, v);
    g_api->ui_set_visible(g_panelMenu, v);
    g_api->ui_set_visible(g_tabMenu, !v);
}

static void onHide(void*) { setPanelVisible(false); }
static void onShow(void*) { setPanelVisible(true); }

static bool haveUi() {
    return g_api->struct_size >= sizeof(ZflipApi) && g_api->ui_win_size && g_api->ui_rect &&
           g_api->ui_label && g_api->ui_menu && g_api->ui_button && g_api->ui_set_text &&
           g_api->ui_set_visible;
}

// startOpen: abierto al crearse. No se usa ui_menu_priority: en GD 2.2091 provoca un SIGSEGV.
static void buildMenu(void* layer, bool startOpen, const char* where) {
    float w = 0, h = 0;
    g_api->ui_win_size(&w, &h);
    if (h <= 0) h = 320.f;
    const float pw = 215.f, ph = 170.f, x0 = 8.f, y0 = h - 8.f - ph;
    const float cx = x0 + pw / 2;
    const int z = 1000;

    g_panelRect = g_api->ui_rect(layer, x0, y0, pw, ph, 0, 0, 0, 190, z);
    g_panelTitle = g_api->ui_label(layer, "ZFlip Mini Menu", 0.42f, cx, y0 + ph - 14.f, z + 1);
    if (g_api->ui_set_color && g_panelTitle) g_api->ui_set_color(g_panelTitle, 140, 130, 255);

    g_panelMenu = g_api->ui_menu(layer, z + 2);
    g_tabMenu = g_api->ui_menu(layer, z + 2);

    g_btnNoclip = g_api->ui_button(g_panelMenu, "Noclip: OFF", 0.36f, cx, y0 + ph - 40.f, onToggleNoclip, nullptr);
    g_btnSpeed = g_api->ui_button(g_panelMenu, "Velocidad: 1.0x", 0.36f, cx, y0 + ph - 66.f, onSpeed, nullptr);
    g_btnUnlock = g_api->ui_button(g_panelMenu, "Desbloquear todo: OFF", 0.36f, cx, y0 + ph - 92.f, onToggleUnlock, nullptr);
    g_btnToast = g_api->ui_button(g_panelMenu, "Aviso en menu: ON", 0.36f, cx, y0 + ph - 118.f, onToggleToast, nullptr);
    g_api->ui_button(g_panelMenu, "Ocultar", 0.36f, cx, y0 + ph - 144.f, onHide, nullptr);
    g_api->ui_button(g_tabMenu, "[ZFlip]", 0.4f, 38.f, h - 14.f, onShow, nullptr);

    refreshNoclip();
    refreshToast();
    refreshUnlock();
    refreshSpeed();
    setPanelVisible(startOpen);
    std::string msg = std::string("mini menu creado en ") + where;
    g_api->log(ZFLIP_LOG_INFO, msg.c_str());
}

// ------------------------------------------------------------------ eventos
static void onLoadingLayer(void* layer) {
    if (haveUi()) buildMenu(layer, true, "la pantalla de carga");
    else g_api->log(ZFLIP_LOG_WARN, "mini menu: el juego no ofrece la API de interfaz");
}

static void onPauseLayer(void* layer) {
    if (haveUi()) buildMenu(layer, false, "el menu de pausa");
}

static void onMenuLayer(void*) {
    if (g_toastOnMenu) g_api->toast("ZFlip Mini Menu activo");
}

// ------------------------------------------------------------------ noclip
static void (*orig_destroyPlayer)(void*, void*, void*) = nullptr;
static void hook_destroyPlayer(void* self, void* player, void* object) {
    if (g_noclip) return;   // no morir
    orig_destroyPlayer(self, player, object);
}

// Engancha una función opcional y deja constancia en el registro.
static bool hookOpt(const char* sym, void* detour, void** orig) {
    char buf[300];
    if (g_api->hook_symbol(sym, detour, orig) != 0) {
        *orig = nullptr;
        snprintf(buf, sizeof(buf), "mini menu: NO se pudo enganchar %s", sym);
        g_api->log(ZFLIP_LOG_WARN, buf);
        return false;
    }
    snprintf(buf, sizeof(buf), "mini menu: enganchado %s", sym);
    g_api->log(ZFLIP_LOG_INFO, buf);
    return true;
}

extern "C" __attribute__((visibility("default"))) int zflip_main(const ZflipApi* api) {
    g_api = api;
    api->log(ZFLIP_LOG_INFO, "mini menu: cargado");
    loadSettings();

    // ZFlip engancha estas capas por ti (API v3/v4); no las enganches tú.
    if (api->struct_size < sizeof(ZflipApi) || !api->on_loading_layer || !api->on_menu_layer ||
        !api->on_pause_layer) {
        api->log(ZFLIP_LOG_ERROR, "mini menu: este launcher es demasiado antiguo (se necesita API v4)");
        return 1;
    }
    int ok = 0;
    if (api->on_loading_layer(onLoadingLayer) != 0) { api->log(ZFLIP_LOG_ERROR, "mini menu: sin evento de carga"); ok++; }
    if (api->on_menu_layer(onMenuLayer) != 0) { api->log(ZFLIP_LOG_ERROR, "mini menu: sin evento de menu"); ok++; }
    if (api->on_pause_layer(onPauseLayer) != 0) { api->log(ZFLIP_LOG_ERROR, "mini menu: sin evento de pausa"); ok++; }

    if (api->hook_symbol("_ZN9PlayLayer13destroyPlayerEP12PlayerObjectP10GameObject",
                         reinterpret_cast<void*>(hook_destroyPlayer),
                         reinterpret_cast<void**>(&orig_destroyPlayer)) != 0) {
        api->log(ZFLIP_LOG_ERROR, "mini menu: no se pudo enganchar PlayLayer::destroyPlayer (noclip no funcionara)");
    }

    // velocidad: CCScheduler::update(float) con el dt multiplicado
    g_speedHooked = hookOpt("_ZN7cocos2d11CCScheduler6updateEf", reinterpret_cast<void*>(hook_schedUpdate),
                            reinterpret_cast<void**>(&orig_schedUpdate));
    if (!g_speedHooked) api->log(ZFLIP_LOG_WARN, "mini menu: velocidad: se intentara con set_time_scale (puede no existir)");
    else setGameSpeed(kSpeeds[g_speedIdx]);

    // desbloquear todo: cada gancho es opcional; con que haya uno el botón funciona
    if (hookOpt("_ZN11GameManager14isIconUnlockedEi8IconType", reinterpret_cast<void*>(hook_isIconUnlocked),
                reinterpret_cast<void**>(&orig_isIconUnlocked))) g_unlockHooks++;
    if (hookOpt("_ZN11GameManager15isColorUnlockedEi10UnlockType", reinterpret_cast<void*>(hook_isColorUnlocked),
                reinterpret_cast<void**>(&orig_isColorUnlocked))) g_unlockHooks++;
    if (hookOpt("_ZN16GameStatsManager14isItemUnlockedE10UnlockTypei", reinterpret_cast<void*>(hook_isItemUnlocked),
                reinterpret_cast<void**>(&orig_isItemUnlocked))) g_unlockHooks++;
    if (g_unlockHooks == 0) api->log(ZFLIP_LOG_WARN, "mini menu: desbloquear todo no estara disponible");

    return ok == 3 ? 1 : 0;
}
